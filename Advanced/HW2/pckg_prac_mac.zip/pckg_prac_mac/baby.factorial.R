#' Calculate \deqn{n!}
#'
#' Calculate \deqn{n!}, "n factorial". 
#' @param n    a nonnegative integer 
#' @return     \deqn{n!} 
#' @details    \code{baby.factorial} calculates
#'             \deqn{n(n-1)(n-2)...(3)(2)(1)}. 
#' @export
#' @examples
#' baby.factorial(3) 
#' x = 4
#' baby.factorial(n=x)
#'
baby.factorial = function(n) {
  stopifnot(n >= 0)
  x = second(n)
  factors = seq_len(x)
  return(prod(factors))
}