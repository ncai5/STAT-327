#' Least absolute deviations regression
#'
#' Build a least absolute deviations regrssion model. 
#' @param x    a vector 
#' @param y    a vector
#' @return     a list containing coefficients,fitted.values and residuals 
#' @details    \code{lad} is a function somewhat like lm().
#'             \code{lad} use optim() with its Nelder-Mead algorithm to minimize 
#'             the sum of absolute deviations(SAD) of data \code{yi}
#'             from predictors. 
#' @export
#' @examples
#' x = area$land
#' y = area$farm
#' g = lad(x,y)
#' print(g)
#' plot(x,y,xlab = "land",ylab = "farm")
#' m = lm(y~x)
#' abline(m)
#' abline(g,col = "red")
#' legend("topleft",legend = c("lm","lad"),col=c("black","red"),lty = c(1,1))
#' new.x = quantile(x,c(0,0.25,0.5,0.75,1))
#' yhat = predict(g,new.x)
#' yhat
#' points(new.x,yhat,col="green",pch = 16)
lad = function(x,y){
  SAD = function(beta,x,y){
    return(sum(abs(y-beta[1]-beta[2]*x)))
  }
  a = as.numeric(stats::lm(y~x)$coefficients[1])
  b = as.numeric(stats::lm(y~x)$coefficients[2])
  out = stats::optim(par = c(a,b),fn = SAD,x = x,y = y,method = "Nelder-Mead")
  beta0 = out$par[1]
  beta1 = out$par[2]
  coefficients = c("(Intercept)"=beta0,"x"=beta1)
  fitted.values = beta0+beta1*x
  residuals = y - (beta0+beta1*x)
  g = list()
  class(g) = "lad"
  g$coefficients = coefficients
  g$fitted.values = fitted.values
  g$residuals = residuals
  return(g)
}



