#' Least absolute deviations regression
#'
#' Takes a lad object and a vector new.x and returns a vector containing
#' lad's prediction at the x values in new.x. ("Description" paragraph)
#' @param object  a "lad" project ("Arguments" section)
#' @param new.x   a new data need to be predicted ("Arguments" section)
#' @param ...     further arguments passed to or from other methods.("Arguments" section)
#' @return        a vector containing lad's predictions at the x values in new.x ("Value" section)
#' @details       \code{predict.lad} use the least absolute deviation regression to predict values
#'                at the x values.("Details" section)
#' @export
#' @examples
#' g = lad(x = area$land,y = area$farm)
#' new.x = c(1,2,3,4,5)
#' predict(g,new.x)
predict.lad = function(object,new.x,...){
  beta0=object$coefficients[1]
  beta1=object$coefficients[2]    
  y=beta0+beta1*new.x
  return(y)
}