#' Land and Farm area of the 50 U.S. States
#'
#' Area is a data set containing farm and land areas of all states in America.
#'
#' @format area is a data frame with 50 rows and 3 variables:
#' \describe{
#'   \item{s}{state (names)}
#'   \item{l}{land (kilometer square)}
#'   \item{f}{farm (kilometer square)}
#' }
#' @source
#' These data are from wikipedia.
#' (\url{http://www.stat.wisc.edu/~jgillett/327-3/2/farmLandArea.csv}) 
"area"