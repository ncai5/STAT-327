#' Least absolute deviations regression
#'
#' Takes a lad object and returns its coefficients. ("Description" paragraph)
#' @param object  a "lad" project ("Arguments" section)
#' @param ...     further arguments passed to or from other methods
#' @return        coefficients of "lad" project ("Value" section)
#' @details       \code{coef.lad} will allow abline(reg) to work,where reg is a 
#'                regression model object returned by lad(),making it easy to add
#'                a lad regression line to a scatterplot. ("Details" section)
#' @export
#' @examples
#' g = lad(x = area$land,y = area$farm)
#' plot(area$land,area$farm)
#' abline(g)
coef.lad=function(object,...){
  return(as.numeric(object$coefficients))
}
