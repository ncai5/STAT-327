#' Least absolute deviations regression
#'
#' Writes the named coefficients vector of least absolute deviation regression to the console. ("Description" paragraph)
#' @param x    an lad object ("Arguments" section)
#' @param ...  further arguments passed to or from other methods ("Arguments" section)
#' @return     a named coefficients vector of "lad" project ("Value" section)
#' @details    \code{print.lad} is a method which writes the named coefficients 
#'             to the console.
#' @export
#' @examples
#' g = lad(x = area$land,y = area$farm)
#' print(g)
print.lad = function(x, ...) {
  cat(sep="", x$coefficient[1], ", ", x$coefficient[2], "\n")
}